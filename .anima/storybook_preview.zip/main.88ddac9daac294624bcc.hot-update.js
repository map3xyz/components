"use strict";
globalThis["webpackHotUpdate_map3xyz_components"]("main",{

/***/ "./src/components/Coin/Coin.tsx":
/*!**************************************!*\
  !*** ./src/components/Coin/Coin.tsx ***!
  \**************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Badge__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Badge */ "./src/components/Badge/index.ts");
/* harmony import */ var _CoinLogo_CoinLogo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../CoinLogo/CoinLogo */ "./src/components/CoinLogo/CoinLogo.tsx");
/* harmony import */ var _Inputs_ReadOnlyText__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Inputs/ReadOnlyText */ "./src/components/Inputs/ReadOnlyText.tsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var _jsxFileName = "/Users/philiplondon/Projects/map3/components/src/components/Coin/Coin.tsx";







const Coin = _ref => {
  var _coin$logo, _coin$logo2, _identifiers, _regex, _regex2, _regex3, _coin$description, _coin$description2, _coin$tags;

  let {
    coin,
    tmpLogo
  } = _ref;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
    className: "h-fit w-full rounded-md border border-neutral-200 p-4 dark:border-neutral-700 dark:bg-neutral-800 dark:text-white",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
      className: "relative w-fit",
      children: [coin !== null && coin !== void 0 && (_coin$logo = coin.logo) !== null && _coin$logo !== void 0 && _coin$logo.svg || coin !== null && coin !== void 0 && (_coin$logo2 = coin.logo) !== null && _coin$logo2 !== void 0 && _coin$logo2.png ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ReactComment, {
          "data-anima": "{\"componentData\":{\"pkg\":\"src/components/CoinLogo/CoinLogo\",\"tagName\":\"CoinLogo\"}}"
        }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_CoinLogo_CoinLogo__WEBPACK_IMPORTED_MODULE_2__["default"], {
          className: "mb-1 flex",
          height: "h-12",
          name: coin.name || '',
          png: coin.logo.png,
          svg: coin.logo.svg,
          width: "w-12",
          "is-anima": "true"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 13,
          columnNumber: 11
        }, undefined)]
      }, void 0, true) : /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
        className: "mb-1 flex h-12 w-12 items-center justify-center overflow-hidden rounded-full bg-neutral-700",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("img", {
          className: "",
          id: tmpLogo
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 23,
          columnNumber: 13
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 22,
        columnNumber: 11
      }, undefined), coin.type ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
        className: "absolute -top-2.5 -right-2.5 flex h-3 w-3 items-center justify-center rounded-full border border-blue-400 bg-blue-200 p-3",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("span", {
          "aria-label": coin.type === 'network' ? 'Network' : 'Asset',
          className: "hint--right hint--no-animate",
          children: coin.type === 'network' ? '🌐' : '💰'
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 29,
          columnNumber: 15
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 11
      }, undefined) : null]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("h1", {
      className: "mb-4 flex gap-2 text-xl font-bold",
      children: [coin === null || coin === void 0 ? void 0 : coin.name, /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ReactComment, {
          "data-anima": "{\"componentData\":{\"pkg\":\"src/components/Badge/Badge\",\"tagName\":\"Badge\"}}"
        }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_Badge__WEBPACK_IMPORTED_MODULE_1__.Badge, {
          color: coin !== null && coin !== void 0 && coin.active ? 'green' : 'red',
          dot: true,
          "is-anima": "true",
          children: coin !== null && coin !== void 0 && coin.active ? 'Active' : 'Not Active'
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 41,
          columnNumber: 9
        }, undefined)]
      }, void 0, true)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 39,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("h4", {
        className: "mt-2 mb-0.5 text-sm font-bold",
        children: "Asset ID"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ReactComment, {
          "data-anima": "{\"componentData\":{\"pkg\":\"src/components/Inputs/ReadOnlyText\",\"tagName\":\"ReadOnlyText\"}}"
        }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_Inputs_ReadOnlyText__WEBPACK_IMPORTED_MODULE_3__["default"], {
          copyButton: true,
          value: coin === null || coin === void 0 ? void 0 : coin.id,
          "is-anima": "true"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 47,
          columnNumber: 9
        }, undefined)]
      }, void 0, true)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 45,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
      className: "mt-2 flex w-full gap-2",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
        className: "w-full",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("h4", {
          className: "mb-0.5 text-sm font-bold",
          children: "Symbol"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 51,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ReactComment, {
            "data-anima": "{\"componentData\":{\"pkg\":\"src/components/Inputs/ReadOnlyText\",\"tagName\":\"ReadOnlyText\"}}"
          }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_Inputs_ReadOnlyText__WEBPACK_IMPORTED_MODULE_3__["default"], {
            value: coin === null || coin === void 0 ? void 0 : coin.symbol,
            "is-anima": "true"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 52,
            columnNumber: 11
          }, undefined)]
        }, void 0, true)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 50,
        columnNumber: 9
      }, undefined), (coin === null || coin === void 0 ? void 0 : coin.type) === 'network' ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
        className: "w-full",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("h4", {
          className: "mb-0.5 text-sm font-bold",
          children: "Chain ID"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 56,
          columnNumber: 13
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ReactComment, {
            "data-anima": "{\"componentData\":{\"pkg\":\"src/components/Inputs/ReadOnlyText\",\"tagName\":\"ReadOnlyText\"}}"
          }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_Inputs_ReadOnlyText__WEBPACK_IMPORTED_MODULE_3__["default"], {
            value: (_identifiers = coin.identifiers) === null || _identifiers === void 0 ? void 0 : _identifiers.chainId,
            "is-anima": "true"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 57,
            columnNumber: 13
          }, undefined)]
        }, void 0, true)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 55,
        columnNumber: 11
      }, undefined) : null]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 49,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
      className: "mt-2 flex w-full gap-2",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
        className: "w-full",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("h4", {
          className: "mb-0.5 text-sm font-bold",
          children: "Decimals"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 63,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ReactComment, {
            "data-anima": "{\"componentData\":{\"pkg\":\"src/components/Inputs/ReadOnlyText\",\"tagName\":\"ReadOnlyText\"}}"
          }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_Inputs_ReadOnlyText__WEBPACK_IMPORTED_MODULE_3__["default"], {
            value: coin.decimals,
            "is-anima": "true"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 64,
            columnNumber: 11
          }, undefined)]
        }, void 0, true)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 62,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
        className: "w-full",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("h4", {
          className: "mb-0.5 whitespace-nowrap text-sm font-bold",
          children: "Network Code"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 67,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ReactComment, {
            "data-anima": "{\"componentData\":{\"pkg\":\"src/components/Inputs/ReadOnlyText\",\"tagName\":\"ReadOnlyText\"}}"
          }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_Inputs_ReadOnlyText__WEBPACK_IMPORTED_MODULE_3__["default"], {
            value: coin === null || coin === void 0 ? void 0 : coin.networkCode,
            "is-anima": "true"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 70,
            columnNumber: 11
          }, undefined)]
        }, void 0, true)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 66,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
        className: "w-full",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("h4", {
          className: "mb-0.5 text-sm font-bold",
          children: "Color"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 73,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ReactComment, {
            "data-anima": "{\"componentData\":{\"pkg\":\"src/components/Inputs/ReadOnlyText\",\"tagName\":\"ReadOnlyText\"}}"
          }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_Inputs_ReadOnlyText__WEBPACK_IMPORTED_MODULE_3__["default"], {
            preview: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
              className: "h-4 w-4 rounded-full",
              style: {
                backgroundColor: coin.color || '#000000'
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 76,
              columnNumber: 15
            }, undefined),
            value: (coin === null || coin === void 0 ? void 0 : coin.color) || '#000000',
            "is-anima": "true"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 74,
            columnNumber: 11
          }, undefined)]
        }, void 0, true)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 72,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 61,
      columnNumber: 7
    }, undefined), coin.type === 'asset' ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
      className: "mt-2",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("h4", {
        className: "mb-0.5 text-sm font-bold",
        children: "Address"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 87,
        columnNumber: 11
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ReactComment, {
          "data-anima": "{\"componentData\":{\"pkg\":\"src/components/Inputs/ReadOnlyText\",\"tagName\":\"ReadOnlyText\"}}"
        }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_Inputs_ReadOnlyText__WEBPACK_IMPORTED_MODULE_3__["default"], {
          copyButton: true,
          value: coin === null || coin === void 0 ? void 0 : coin.address,
          "is-anima": "true"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 88,
          columnNumber: 11
        }, undefined)]
      }, void 0, true)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 86,
      columnNumber: 9
    }, undefined) : /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
      className: "mt-2 flex w-full gap-2",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
        className: "w-full",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("h4", {
          className: "mb-0.5 text-sm font-bold",
          children: "Address Regex"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 93,
          columnNumber: 13
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ReactComment, {
            "data-anima": "{\"componentData\":{\"pkg\":\"src/components/Inputs/ReadOnlyText\",\"tagName\":\"ReadOnlyText\"}}"
          }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_Inputs_ReadOnlyText__WEBPACK_IMPORTED_MODULE_3__["default"], {
            copyButton: true,
            value: (_regex = coin.regex) === null || _regex === void 0 ? void 0 : _regex.address,
            "is-anima": "true"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 94,
            columnNumber: 13
          }, undefined)]
        }, void 0, true)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 92,
        columnNumber: 11
      }, undefined), (_regex2 = coin.regex) !== null && _regex2 !== void 0 && _regex2.memo ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
        className: "w-full",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("h4", {
          className: "mb-0.5 text-sm font-bold",
          children: "Memo Regex"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 98,
          columnNumber: 15
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ReactComment, {
            "data-anima": "{\"componentData\":{\"pkg\":\"src/components/Inputs/ReadOnlyText\",\"tagName\":\"ReadOnlyText\"}}"
          }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_Inputs_ReadOnlyText__WEBPACK_IMPORTED_MODULE_3__["default"], {
            copyButton: true,
            value: (_regex3 = coin.regex) === null || _regex3 === void 0 ? void 0 : _regex3.memo,
            "is-anima": "true"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 99,
            columnNumber: 15
          }, undefined)]
        }, void 0, true)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 97,
        columnNumber: 13
      }, undefined) : null]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 91,
      columnNumber: 9
    }, undefined), coin !== null && coin !== void 0 && (_coin$description = coin.description) !== null && _coin$description !== void 0 && _coin$description.en ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
      className: "mt-2",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("h4", {
        className: "mb-0.5 text-sm font-bold",
        children: "Description"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 106,
        columnNumber: 11
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("p", {
        className: "text-sm leading-4",
        children: (coin === null || coin === void 0 ? void 0 : (_coin$description2 = coin.description) === null || _coin$description2 === void 0 ? void 0 : _coin$description2.en) || ''
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 107,
        columnNumber: 11
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 105,
      columnNumber: 9
    }, undefined) : null, coin.tags && coin.tags.length > 0 ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
      className: "mt-2",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("h4", {
        className: "mb-0.5 text-sm font-bold",
        children: "Tags"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 112,
        columnNumber: 11
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
        className: "flex flex-wrap gap-1",
        children: (_coin$tags = coin.tags) === null || _coin$tags === void 0 ? void 0 : _coin$tags.map(tag => {
          return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ReactComment, {
              "data-anima": "{\"componentData\":{\"pkg\":\"src/components/Badge/Badge\",\"tagName\":\"Badge\"}}"
            }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_Badge__WEBPACK_IMPORTED_MODULE_1__.Badge, {
              color: "green",
              dot: true,
              "is-anima": "true",
              children: tag
            }, tag, false, {
              fileName: _jsxFileName,
              lineNumber: 116,
              columnNumber: 17
            }, undefined)]
          }, void 0, true);
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 113,
        columnNumber: 11
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 111,
      columnNumber: 9
    }, undefined) : null, coin !== null && coin !== void 0 && coin.maps && Object.keys(coin.maps).length ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
      className: "mt-2",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("h4", {
        className: "mb-0.5 flex items-center gap-1 text-sm font-bold",
        children: ["Maps", ' ', /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("span", {
          "aria-label": "Maps represent the cross-chain equivalent of the asset or network.",
          className: "hint--top font-normal",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("i", {
            className: "fa fa-question-circle"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 132,
            columnNumber: 15
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 128,
          columnNumber: 13
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 126,
        columnNumber: 11
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
        className: "group flex flex-wrap",
        children: Object.keys(coin.maps).map(map => {
          if (!map) return null;
          if (!(coin !== null && coin !== void 0 && coin.maps)) return null;
          if (!coin.maps[map]) return null;
          return Object.values(coin.maps[map] || {}).map(mapping => {
            var _mapping$toNetwork$lo, _mapping$toNetwork$lo2;

            if (!mapping) return null;
            return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("a", {
              "aria-label": `${mapping.toNetwork.name} - (${map})`,
              className: "hint--top -ml-3 rounded-full bg-white p-1 transition-all duration-75 first:-ml-1 group-hover:ml-0 group-hover:first:-ml-1 dark:bg-neutral-800",
              href: `/network/${mapping.toNetwork.networkCode}`,
              target: "_blank",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(ReactComment, {
                  "data-anima": "{\"componentData\":{\"pkg\":\"src/components/CoinLogo/CoinLogo\",\"tagName\":\"CoinLogo\"}}"
                }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_CoinLogo_CoinLogo__WEBPACK_IMPORTED_MODULE_2__["default"], {
                  height: "h-6",
                  name: mapping.toNetwork.name || '',
                  png: (_mapping$toNetwork$lo = mapping.toNetwork.logo) === null || _mapping$toNetwork$lo === void 0 ? void 0 : _mapping$toNetwork$lo.png,
                  svg: (_mapping$toNetwork$lo2 = mapping.toNetwork.logo) === null || _mapping$toNetwork$lo2 === void 0 ? void 0 : _mapping$toNetwork$lo2.svg,
                  width: "w-6",
                  "is-anima": "true"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 151,
                  columnNumber: 23
                }, undefined)]
              }, void 0, true)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 145,
              columnNumber: 21
            }, undefined);
          });
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 135,
        columnNumber: 11
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 125,
      columnNumber: 9
    }, undefined) : null, coin.links &&
    /*@ts-ignore*/
    Object.keys(coin === null || coin === void 0 ? void 0 : coin.links).filter(link => coin.links[link]).length > 0 ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
      className: "mt-2",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("h4", {
        className: "mb-0.5 text-sm font-bold",
        children: "Links"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 171,
        columnNumber: 11
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
        className: "flex gap-2",
        children: coin.links && Object.keys(coin.links) // @ts-ignore
        .filter(link => coin.links[link]).map(link =>
        /*#__PURE__*/
        // @ts-ignore
        (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("a", {
          href: coin.links[link],
          target: "_blank",
          children: [link === 'website' ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("span", {
            "aria-label": "Website",
            className: "hint--top hint--no-animate",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("i", {
              className: "fas fa-globe"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 185,
              columnNumber: 25
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 181,
            columnNumber: 23
          }, undefined) : link === 'explorer' ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("span", {
            "aria-label": "Explorer",
            className: "hint--top hint--no-animate",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("i", {
              className: "fas fa-search"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 192,
              columnNumber: 25
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 188,
            columnNumber: 23
          }, undefined) : link === 'twitter' ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("span", {
            "aria-label": "Twitter",
            className: "hint--top hint--no-animate",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("i", {
              className: "fa fa-brands fa-twitter"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 199,
              columnNumber: 25
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 195,
            columnNumber: 23
          }, undefined) : link === 'research' ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("span", {
            "aria-label": "Research",
            className: "hint--top hint--no-animate",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("i", {
              className: "fas fa-flask"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 206,
              columnNumber: 25
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 202,
            columnNumber: 23
          }, undefined) : link === 'github' ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("span", {
            "aria-label": "GitHub",
            className: "hint--top hint--no-animate",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("i", {
              className: "fa fa-brands fa-github"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 213,
              columnNumber: 25
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 209,
            columnNumber: 23
          }, undefined) : link === 'medium' ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("span", {
            "aria-label": "Medium",
            className: "hint--top hint--no-animate",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("i", {
              className: "fa fa-brands fa-medium"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 220,
              columnNumber: 25
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 216,
            columnNumber: 23
          }, undefined) : link === 'reddit' ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("span", {
            "aria-label": "Reddit",
            className: "hint--top hint--no-animate",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("i", {
              className: "fa fa-brands fa-reddit"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 227,
              columnNumber: 25
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 223,
            columnNumber: 23
          }, undefined) : link === 'whitepaper' ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("span", {
            "aria-label": "Whitepaper",
            className: "hint--top hint--no-animate",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("i", {
              className: "fa fa-file-code"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 234,
              columnNumber: 25
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 230,
            columnNumber: 23
          }, undefined) : '🔗', ' ']
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 179,
          columnNumber: 19
        }, undefined))
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 172,
        columnNumber: 11
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 170,
      columnNumber: 9
    }, undefined) : null]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 10,
    columnNumber: 5
  }, undefined);
};

_c = Coin;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Coin);

if (!window.ReactComment) {
  window.ReactComment = props => {
    try {
      const React = __webpack_require__(/*! react */ "./node_modules/react/index.js");

      const animaData = props['data-anima'];
      if (!animaData) return null;
      const ref = React.createRef();
      React.useLayoutEffect(() => {
        let el = null;
        let parent = null;
        let comm = null;

        if (ref.current) {
          el = ref.current;
          parent = el.parentNode;
          comm = window.document.createComment(animaData);

          try {
            if (parent && parent.contains(el)) {
              parent.replaceChild(comm, el);
            }
          } catch (err) {
            console.error(err);
          }
        }

        return () => {
          if (parent && el && comm) {
            parent.replaceChild(el, comm);
          }
        };
      }, []);
      return React.createElement('span', {
        ref,
        style: {
          display: 'none'
        }
      }, []);
    } catch (e) {
      return null;
    }
  };
}

var _c;

__webpack_require__.$Refresh$.register(_c, "Coin");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}
try {
    // @ts-ignore
    Coin.displayName = "Coin";
    // @ts-ignore
    Coin.__docgenInfo = { "description": "", "displayName": "Coin", "props": { "coin": { "defaultValue": null, "description": "", "name": "coin", "required": true, "type": { "name": "Partial<Network | Asset> & { maps?: { direct_issuance?: Map[] | undefined; bridged?: Map[] | undefined; wrapped?: Map[] | undefined; } | undefined; }" } }, "tmpLogo": { "defaultValue": null, "description": "", "name": "tmpLogo", "required": false, "type": { "name": "string" } } } };
    // @ts-ignore
    if (typeof STORYBOOK_REACT_CLASSES !== "undefined")
        // @ts-ignore
        STORYBOOK_REACT_CLASSES["src/components/Coin/Coin.tsx#Coin"] = { docgenInfo: Coin.__docgenInfo, name: "Coin", path: "src/components/Coin/Coin.tsx#Coin" };
}
catch (__react_docgen_typescript_loader_error) { }

/***/ })

});
//# sourceMappingURL=main.88ddac9daac294624bcc.hot-update.js.map