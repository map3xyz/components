"use strict";
globalThis["webpackHotUpdate_map3xyz_components"]("main",{

/***/ "./src/components/Inputs/Textarea.tsx":
/*!********************************************!*\
  !*** ./src/components/Inputs/Textarea.tsx ***!
  \********************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/@storybook/builder-webpack5/node_modules/react/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/@storybook/builder-webpack5/node_modules/react/jsx-dev-runtime.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var _jsxFileName = "/Users/philiplondon/Projects/map3/components/src/components/Inputs/Textarea.tsx";



const Textarea = props => {
  const {
    label
  } = props;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
    className: "flex flex-col dark:text-white",
    children: [label ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("label", {
      className: "mb-1 text-xs",
      htmlFor: props.name,
      children: props.label
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 9
    }, undefined) : null, /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("textarea", {
      className: "rounded-md border border-neutral-200 bg-neutral-100 px-2 py-1 text-sm !outline-none !ring-0 transition-all focus:border-neutral-300 dark:border-neutral-700 dark:bg-neutral-900 dark:focus:border-neutral-500",
      id: props.name,
      ...props
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 7,
    columnNumber: 5
  }, undefined);
};

_c = Textarea;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Textarea);

if (!window.ReactComment) {
  window.ReactComment = props => {
    try {
      const React = __webpack_require__(/*! react */ "./node_modules/@storybook/builder-webpack5/node_modules/react/index.js");

      const animaData = props['data-anima'];
      if (!animaData) return null;
      const ref = React.createRef();
      React.useLayoutEffect(() => {
        let el = null;
        let parent = null;
        let comm = null;

        if (ref.current) {
          el = ref.current;
          parent = el.parentNode;
          comm = window.document.createComment(animaData);

          try {
            if (parent && parent.contains(el)) {
              parent.replaceChild(comm, el);
            }
          } catch (err) {
            console.error(err);
          }
        }

        return () => {
          if (parent && el && comm) {
            parent.replaceChild(el, comm);
          }
        };
      }, []);
      return React.createElement('span', {
        ref,
        style: {
          display: 'none'
        }
      }, []);
    } catch (e) {
      return null;
    }
  };
}

var _c;

__webpack_require__.$Refresh$.register(_c, "Textarea");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}
try {
    // @ts-ignore
    Textarea.displayName = "Textarea";
    // @ts-ignore
    Textarea.__docgenInfo = { "description": "", "displayName": "Textarea", "props": { "label": { "defaultValue": null, "description": "", "name": "label", "required": false, "type": { "name": "string" } } } };
    // @ts-ignore
    if (typeof STORYBOOK_REACT_CLASSES !== "undefined")
        // @ts-ignore
        STORYBOOK_REACT_CLASSES["src/components/Inputs/Textarea.tsx#Textarea"] = { docgenInfo: Textarea.__docgenInfo, name: "Textarea", path: "src/components/Inputs/Textarea.tsx#Textarea" };
}
catch (__react_docgen_typescript_loader_error) { }

/***/ })

});
//# sourceMappingURL=main.e320c30a81563d87da59.hot-update.js.map