"use strict";
globalThis["webpackHotUpdate_map3xyz_components"]("main",{

/***/ "./src/components/Button/Button.stories.tsx":
/*!**************************************************!*\
  !*** ./src/components/Button/Button.stories.tsx ***!
  \**************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "All": () => (/* binding */ All),
/* harmony export */   "Dashed": () => (/* binding */ Dashed),
/* harmony export */   "Default": () => (/* binding */ Default),
/* harmony export */   "Link": () => (/* binding */ Link),
/* harmony export */   "Loading": () => (/* binding */ Loading),
/* harmony export */   "Primary": () => (/* binding */ Primary),
/* harmony export */   "Secondary": () => (/* binding */ Secondary),
/* harmony export */   "Success": () => (/* binding */ Success),
/* harmony export */   "Text": () => (/* binding */ Text),
/* harmony export */   "Warning": () => (/* binding */ Warning),
/* harmony export */   "__namedExportsOrder": () => (/* binding */ __namedExportsOrder),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Button */ "./src/components/Button/Button.tsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/@storybook/builder-webpack5/node_modules/react/jsx-dev-runtime.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var _jsxFileName = "/Users/philiplondon/Projects/map3/components/src/components/Button/Button.stories.tsx";

/* eslint-disable */
// @ts-nocheck
// @ts-ignore
var __STORY__ = "import { ComponentMeta, Story } from '@storybook/react';\n\nimport Button, { Props as Map3ButtonProps } from './Button';\n\nexport default {\n  component: Button,\n  title: 'Inputs/Button',\n} as ComponentMeta<typeof Button>;\n\nconst Template: Story<Map3ButtonProps> = (args) => (\n  <Button {...args}>Button</Button>\n);\n\nexport const Primary = Template.bind({});\nPrimary.args = {};\nexport const Secondary = Template.bind({});\nSecondary.args = {\n  type: 'secondary',\n};\nexport const Default = Template.bind({});\nDefault.args = {\n  type: 'default',\n};\nexport const Dashed = Template.bind({});\nDashed.args = {\n  type: 'dashed',\n};\nexport const Text = Template.bind({});\nText.args = {\n  type: 'text',\n};\nexport const Link = Template.bind({});\nLink.args = {\n  type: 'link',\n};\nexport const Loading = Template.bind({});\nLoading.args = {\n  loading: true,\n};\nexport const Success = Template.bind({});\nSuccess.args = {\n  success: true,\n};\nexport const Warning = Template.bind({});\nWarning.args = {\n  additionalTypes: 'warning',\n};\n\nexport const All = () => (\n  <div className=\"flex flex-col items-start gap-2\" style={{ width: '500px' }}>\n    <div className=\"flex w-full items-start gap-2\">\n      <Button>Primary</Button>\n      <Button type=\"secondary\">Secondary</Button>\n      <Button type=\"default\">Default</Button>\n      <Button type=\"dashed\">Dashed</Button>\n      <Button type=\"text\">Text</Button>\n      <Button type=\"link\">Link</Button>\n      <Button loading>Loading</Button>\n      <Button success>Success</Button>\n      <Button additionalTypes=\"warning\">Warning</Button>\n    </div>\n    <div className=\"flex gap-2\">\n      <div>\n        <Button size=\"tiny\">tiny</Button>\n      </div>\n      <div>\n        <Button size=\"small\">small</Button>\n      </div>\n      <div>\n        <Button size=\"medium\">medium</Button>\n      </div>\n      <div>\n        <Button size=\"large\">large</Button>\n      </div>\n      <div>\n        <Button size=\"xlarge\">xlarge</Button>\n      </div>\n    </div>\n  </div>\n);\n"; // @ts-ignore

var __LOCATIONS_MAP__ = {
  "Primary": {
    "startLoc": {
      "col": 41,
      "line": 10
    },
    "endLoc": {
      "col": 1,
      "line": 12
    },
    "startBody": {
      "col": 41,
      "line": 10
    },
    "endBody": {
      "col": 1,
      "line": 12
    }
  },
  "Secondary": {
    "startLoc": {
      "col": 41,
      "line": 10
    },
    "endLoc": {
      "col": 1,
      "line": 12
    },
    "startBody": {
      "col": 41,
      "line": 10
    },
    "endBody": {
      "col": 1,
      "line": 12
    }
  },
  "Default": {
    "startLoc": {
      "col": 41,
      "line": 10
    },
    "endLoc": {
      "col": 1,
      "line": 12
    },
    "startBody": {
      "col": 41,
      "line": 10
    },
    "endBody": {
      "col": 1,
      "line": 12
    }
  },
  "Dashed": {
    "startLoc": {
      "col": 41,
      "line": 10
    },
    "endLoc": {
      "col": 1,
      "line": 12
    },
    "startBody": {
      "col": 41,
      "line": 10
    },
    "endBody": {
      "col": 1,
      "line": 12
    }
  },
  "Text": {
    "startLoc": {
      "col": 41,
      "line": 10
    },
    "endLoc": {
      "col": 1,
      "line": 12
    },
    "startBody": {
      "col": 41,
      "line": 10
    },
    "endBody": {
      "col": 1,
      "line": 12
    }
  },
  "Link": {
    "startLoc": {
      "col": 41,
      "line": 10
    },
    "endLoc": {
      "col": 1,
      "line": 12
    },
    "startBody": {
      "col": 41,
      "line": 10
    },
    "endBody": {
      "col": 1,
      "line": 12
    }
  },
  "Loading": {
    "startLoc": {
      "col": 41,
      "line": 10
    },
    "endLoc": {
      "col": 1,
      "line": 12
    },
    "startBody": {
      "col": 41,
      "line": 10
    },
    "endBody": {
      "col": 1,
      "line": 12
    }
  },
  "Success": {
    "startLoc": {
      "col": 41,
      "line": 10
    },
    "endLoc": {
      "col": 1,
      "line": 12
    },
    "startBody": {
      "col": 41,
      "line": 10
    },
    "endBody": {
      "col": 1,
      "line": 12
    }
  },
  "Warning": {
    "startLoc": {
      "col": 41,
      "line": 10
    },
    "endLoc": {
      "col": 1,
      "line": 12
    },
    "startBody": {
      "col": 41,
      "line": 10
    },
    "endBody": {
      "col": 1,
      "line": 12
    }
  },
  "All": {
    "startLoc": {
      "col": 19,
      "line": 49
    },
    "endLoc": {
      "col": 1,
      "line": 80
    },
    "startBody": {
      "col": 19,
      "line": 49
    },
    "endBody": {
      "col": 1,
      "line": 80
    }
  }
};



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  component: _Button__WEBPACK_IMPORTED_MODULE_0__["default"],
  title: 'Inputs/Button'
});

const Template = args => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(ReactComment, {
    "data-anima": "{\"componentData\":{\"pkg\":\"src/components/Button/Button\",\"tagName\":\"Button\"}}"
  }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_Button__WEBPACK_IMPORTED_MODULE_0__["default"], { ...args,
    "is-anima": "true",
    children: "Button"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 19,
    columnNumber: 3
  }, undefined)]
}, void 0, true);

_c = Template;
const Primary = Template.bind({});
;
Primary.args = {};
const Secondary = Template.bind({});
;
Secondary.args = {
  type: 'secondary'
};
const Default = Template.bind({});
;
Default.args = {
  type: 'default'
};
const Dashed = Template.bind({});
;
Dashed.args = {
  type: 'dashed'
};
const Text = Template.bind({});
;
Text.args = {
  type: 'text'
};
const Link = Template.bind({});
;
Link.args = {
  type: 'link'
};
const Loading = Template.bind({});
;
Loading.args = {
  loading: true
};
const Success = Template.bind({});
;
Success.args = {
  success: true
};
const Warning = Template.bind({});
;
Warning.args = {
  additionalTypes: 'warning'
};
const All = () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
  className: "flex flex-col items-start gap-2",
  style: {
    width: '500px'
  },
  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
    className: "flex w-full items-start gap-2",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(ReactComment, {
        "data-anima": "{\"componentData\":{\"pkg\":\"src/components/Button/Button\",\"tagName\":\"Button\"}}"
      }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_Button__WEBPACK_IMPORTED_MODULE_0__["default"], {
        "is-anima": "true",
        children: "Primary"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 60,
        columnNumber: 7
      }, undefined)]
    }, void 0, true), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(ReactComment, {
        "data-anima": "{\"componentData\":{\"pkg\":\"src/components/Button/Button\",\"tagName\":\"Button\"}}"
      }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_Button__WEBPACK_IMPORTED_MODULE_0__["default"], {
        type: "secondary",
        "is-anima": "true",
        children: "Secondary"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 61,
        columnNumber: 7
      }, undefined)]
    }, void 0, true), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(ReactComment, {
        "data-anima": "{\"componentData\":{\"pkg\":\"src/components/Button/Button\",\"tagName\":\"Button\"}}"
      }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_Button__WEBPACK_IMPORTED_MODULE_0__["default"], {
        type: "default",
        "is-anima": "true",
        children: "Default"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 62,
        columnNumber: 7
      }, undefined)]
    }, void 0, true), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(ReactComment, {
        "data-anima": "{\"componentData\":{\"pkg\":\"src/components/Button/Button\",\"tagName\":\"Button\"}}"
      }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_Button__WEBPACK_IMPORTED_MODULE_0__["default"], {
        type: "dashed",
        "is-anima": "true",
        children: "Dashed"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 7
      }, undefined)]
    }, void 0, true), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(ReactComment, {
        "data-anima": "{\"componentData\":{\"pkg\":\"src/components/Button/Button\",\"tagName\":\"Button\"}}"
      }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_Button__WEBPACK_IMPORTED_MODULE_0__["default"], {
        type: "text",
        "is-anima": "true",
        children: "Text"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 64,
        columnNumber: 7
      }, undefined)]
    }, void 0, true), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(ReactComment, {
        "data-anima": "{\"componentData\":{\"pkg\":\"src/components/Button/Button\",\"tagName\":\"Button\"}}"
      }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_Button__WEBPACK_IMPORTED_MODULE_0__["default"], {
        type: "link",
        "is-anima": "true",
        children: "Link"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 65,
        columnNumber: 7
      }, undefined)]
    }, void 0, true), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(ReactComment, {
        "data-anima": "{\"componentData\":{\"pkg\":\"src/components/Button/Button\",\"tagName\":\"Button\"}}"
      }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_Button__WEBPACK_IMPORTED_MODULE_0__["default"], {
        loading: true,
        "is-anima": "true",
        children: "Loading"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 66,
        columnNumber: 7
      }, undefined)]
    }, void 0, true), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(ReactComment, {
        "data-anima": "{\"componentData\":{\"pkg\":\"src/components/Button/Button\",\"tagName\":\"Button\"}}"
      }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_Button__WEBPACK_IMPORTED_MODULE_0__["default"], {
        success: true,
        "is-anima": "true",
        children: "Success"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 67,
        columnNumber: 7
      }, undefined)]
    }, void 0, true), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(ReactComment, {
        "data-anima": "{\"componentData\":{\"pkg\":\"src/components/Button/Button\",\"tagName\":\"Button\"}}"
      }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_Button__WEBPACK_IMPORTED_MODULE_0__["default"], {
        additionalTypes: "warning",
        "is-anima": "true",
        children: "Warning"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 68,
        columnNumber: 7
      }, undefined)]
    }, void 0, true)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 59,
    columnNumber: 5
  }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
    className: "flex gap-2",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(ReactComment, {
          "data-anima": "{\"componentData\":{\"pkg\":\"src/components/Button/Button\",\"tagName\":\"Button\"}}"
        }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_Button__WEBPACK_IMPORTED_MODULE_0__["default"], {
          size: "tiny",
          "is-anima": "true",
          children: "tiny"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 72,
          columnNumber: 9
        }, undefined)]
      }, void 0, true)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 71,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(ReactComment, {
          "data-anima": "{\"componentData\":{\"pkg\":\"src/components/Button/Button\",\"tagName\":\"Button\"}}"
        }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_Button__WEBPACK_IMPORTED_MODULE_0__["default"], {
          size: "small",
          "is-anima": "true",
          children: "small"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 75,
          columnNumber: 9
        }, undefined)]
      }, void 0, true)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 74,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(ReactComment, {
          "data-anima": "{\"componentData\":{\"pkg\":\"src/components/Button/Button\",\"tagName\":\"Button\"}}"
        }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_Button__WEBPACK_IMPORTED_MODULE_0__["default"], {
          size: "medium",
          "is-anima": "true",
          children: "medium"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 78,
          columnNumber: 9
        }, undefined)]
      }, void 0, true)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 77,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(ReactComment, {
          "data-anima": "{\"componentData\":{\"pkg\":\"src/components/Button/Button\",\"tagName\":\"Button\"}}"
        }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_Button__WEBPACK_IMPORTED_MODULE_0__["default"], {
          size: "large",
          "is-anima": "true",
          children: "large"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 81,
          columnNumber: 9
        }, undefined)]
      }, void 0, true)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 80,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(ReactComment, {
          "data-anima": "{\"componentData\":{\"pkg\":\"src/components/Button/Button\",\"tagName\":\"Button\"}}"
        }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_Button__WEBPACK_IMPORTED_MODULE_0__["default"], {
          size: "xlarge",
          "is-anima": "true",
          children: "xlarge"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 84,
          columnNumber: 9
        }, undefined)]
      }, void 0, true)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 83,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 70,
    columnNumber: 5
  }, undefined)]
}, void 0, true, {
  fileName: _jsxFileName,
  lineNumber: 58,
  columnNumber: 3
}, undefined);
_c2 = All;
Primary.parameters = {
  storySource: {
    source: "(args) => (\n  <Button {...args}>Button</Button>\n)"
  },
  ...Primary.parameters
};
Secondary.parameters = {
  storySource: {
    source: "(args) => (\n  <Button {...args}>Button</Button>\n)"
  },
  ...Secondary.parameters
};
Default.parameters = {
  storySource: {
    source: "(args) => (\n  <Button {...args}>Button</Button>\n)"
  },
  ...Default.parameters
};
Dashed.parameters = {
  storySource: {
    source: "(args) => (\n  <Button {...args}>Button</Button>\n)"
  },
  ...Dashed.parameters
};
Text.parameters = {
  storySource: {
    source: "(args) => (\n  <Button {...args}>Button</Button>\n)"
  },
  ...Text.parameters
};
Link.parameters = {
  storySource: {
    source: "(args) => (\n  <Button {...args}>Button</Button>\n)"
  },
  ...Link.parameters
};
Loading.parameters = {
  storySource: {
    source: "(args) => (\n  <Button {...args}>Button</Button>\n)"
  },
  ...Loading.parameters
};
Success.parameters = {
  storySource: {
    source: "(args) => (\n  <Button {...args}>Button</Button>\n)"
  },
  ...Success.parameters
};
Warning.parameters = {
  storySource: {
    source: "(args) => (\n  <Button {...args}>Button</Button>\n)"
  },
  ...Warning.parameters
};
All.parameters = {
  storySource: {
    source: "() => (\n  <div className=\"flex flex-col items-start gap-2\" style={{ width: '500px' }}>\n    <div className=\"flex w-full items-start gap-2\">\n      <Button>Primary</Button>\n      <Button type=\"secondary\">Secondary</Button>\n      <Button type=\"default\">Default</Button>\n      <Button type=\"dashed\">Dashed</Button>\n      <Button type=\"text\">Text</Button>\n      <Button type=\"link\">Link</Button>\n      <Button loading>Loading</Button>\n      <Button success>Success</Button>\n      <Button additionalTypes=\"warning\">Warning</Button>\n    </div>\n    <div className=\"flex gap-2\">\n      <div>\n        <Button size=\"tiny\">tiny</Button>\n      </div>\n      <div>\n        <Button size=\"small\">small</Button>\n      </div>\n      <div>\n        <Button size=\"medium\">medium</Button>\n      </div>\n      <div>\n        <Button size=\"large\">large</Button>\n      </div>\n      <div>\n        <Button size=\"xlarge\">xlarge</Button>\n      </div>\n    </div>\n  </div>\n)"
  },
  ...All.parameters
};

if (!window.ReactComment) {
  window.ReactComment = props => {
    try {
      const React = __webpack_require__(/*! react */ "./node_modules/@storybook/builder-webpack5/node_modules/react/index.js");

      const animaData = props['data-anima'];
      if (!animaData) return null;
      const ref = React.createRef();
      React.useLayoutEffect(() => {
        let el = null;
        let parent = null;
        let comm = null;

        if (ref.current) {
          el = ref.current;
          parent = el.parentNode;
          comm = window.document.createComment(animaData);

          try {
            if (parent && parent.contains(el)) {
              parent.replaceChild(comm, el);
            }
          } catch (err) {
            console.error(err);
          }
        }

        return () => {
          if (parent && el && comm) {
            parent.replaceChild(el, comm);
          }
        };
      }, []);
      return React.createElement('span', {
        ref,
        style: {
          display: 'none'
        }
      }, []);
    } catch (e) {
      return null;
    }
  };
}

window["__ANIMA__STORY__./src/components/Button/Button.stories.tsx"] = {
  "imports": {
    "src/components/Button/Button": [{
      "name": "Button",
      "isDefault": true,
      "key": "src/components/Button/Button"
    }],
    "react/jsx-dev-runtime": [{
      "name": "_jsxDEV",
      "isDefault": false,
      "key": "react/jsx-dev-runtime/_jsxDEV"
    }]
  },
  "title": "Inputs/Button",
  "component": "Button"
};

var _c, _c2;

__webpack_require__.$Refresh$.register(_c, "Template");
__webpack_require__.$Refresh$.register(_c2, "All");
const __namedExportsOrder = ["Primary", "Secondary", "Default", "Dashed", "Text", "Link", "Loading", "Success", "Warning", "All"];

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ })

});
//# sourceMappingURL=main.f17c803e86dda47cb16e.hot-update.js.map