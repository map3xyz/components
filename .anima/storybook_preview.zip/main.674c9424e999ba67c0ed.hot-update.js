"use strict";
globalThis["webpackHotUpdate_map3xyz_components"]("main",{

/***/ "./src/components/CoinLogo/CoinLogo.tsx":
/*!**********************************************!*\
  !*** ./src/components/CoinLogo/CoinLogo.tsx ***!
  \**********************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_blockies__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-blockies */ "./node_modules/react-blockies/dist/main.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var _jsxFileName = "/Users/philiplondon/Projects/map3/components/src/components/CoinLogo/CoinLogo.tsx",
    _s = __webpack_require__.$Refresh$.signature();






const CoinLogo = _ref => {
  _s();

  let {
    className,
    height,
    logo,
    width
  } = _ref;
  const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);

  if (error) {
    console.log(Number(height.split('h-')[1]) * 4 + 'px');
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(ReactComment, {
        "data-anima": "{\"componentData\":{\"pkg\":\"react-blockies\",\"tagName\":\"Blockies\"}}"
      }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(react_blockies__WEBPACK_IMPORTED_MODULE_1__["default"], {
        className: `block rounded-full ${height} ${width}`,
        seed: (logo === null || logo === void 0 ? void 0 : logo.png) || (logo === null || logo === void 0 ? void 0 : logo.svg),
        size: Number(height.split('h-')[1]),
        "is-anima": "true"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 11,
        columnNumber: 7
      }, undefined)]
    }, void 0, true);
  }

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
    className: `flex items-center justify-center rounded-full bg-neutral-200 dark:bg-white ${className} ${height} ${width}`,
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("img", {
      className: `block rounded-full ${height} ${width}`,
      onError: () => {
        setError(true);
      },
      src: (logo === null || logo === void 0 ? void 0 : logo.svg) || (logo === null || logo === void 0 ? void 0 : logo.png)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 23,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 20,
    columnNumber: 5
  }, undefined);
};

_s(CoinLogo, "AvrsuJm02Cqlq6/LWpvA21zDecQ=");

_c = CoinLogo;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CoinLogo);

if (!window.ReactComment) {
  window.ReactComment = props => {
    try {
      const React = __webpack_require__(/*! react */ "./node_modules/react/index.js");

      const animaData = props['data-anima'];
      if (!animaData) return null;
      const ref = React.createRef();
      React.useLayoutEffect(() => {
        let el = null;
        let parent = null;
        let comm = null;

        if (ref.current) {
          el = ref.current;
          parent = el.parentNode;
          comm = window.document.createComment(animaData);

          try {
            if (parent && parent.contains(el)) {
              parent.replaceChild(comm, el);
            }
          } catch (err) {
            console.error(err);
          }
        }

        return () => {
          if (parent && el && comm) {
            parent.replaceChild(el, comm);
          }
        };
      }, []);
      return React.createElement('span', {
        ref,
        style: {
          display: 'none'
        }
      }, []);
    } catch (e) {
      return null;
    }
  };
}

var _c;

__webpack_require__.$Refresh$.register(_c, "CoinLogo");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}
try {
    // @ts-ignore
    CoinLogo.displayName = "CoinLogo";
    // @ts-ignore
    CoinLogo.__docgenInfo = { "description": "", "displayName": "CoinLogo", "props": { "className": { "defaultValue": null, "description": "", "name": "className", "required": false, "type": { "name": "string" } }, "height": { "defaultValue": null, "description": "", "name": "height", "required": true, "type": { "name": "string" } }, "logo": { "defaultValue": null, "description": "", "name": "logo", "required": false, "type": { "name": "Logos | null" } }, "width": { "defaultValue": null, "description": "", "name": "width", "required": true, "type": { "name": "string" } } } };
    // @ts-ignore
    if (typeof STORYBOOK_REACT_CLASSES !== "undefined")
        // @ts-ignore
        STORYBOOK_REACT_CLASSES["src/components/CoinLogo/CoinLogo.tsx#CoinLogo"] = { docgenInfo: CoinLogo.__docgenInfo, name: "CoinLogo", path: "src/components/CoinLogo/CoinLogo.tsx#CoinLogo" };
}
catch (__react_docgen_typescript_loader_error) { }

/***/ })

});
//# sourceMappingURL=main.674c9424e999ba67c0ed.hot-update.js.map