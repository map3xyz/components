"use strict";
globalThis["webpackHotUpdate_map3xyz_components"]("main",{

/***/ "./src/components/CryptoAddress/CryptoAddress.stories.tsx":
/*!****************************************************************!*\
  !*** ./src/components/CryptoAddress/CryptoAddress.stories.tsx ***!
  \****************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Default": () => (/* binding */ Default),
/* harmony export */   "__namedExportsOrder": () => (/* binding */ __namedExportsOrder),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "withRightHint": () => (/* binding */ withRightHint)
/* harmony export */ });
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! . */ "./src/components/CryptoAddress/index.ts");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var _jsxFileName = "/Users/philiplondon/Projects/map3/components/src/components/CryptoAddress/CryptoAddress.stories.tsx";

/* eslint-disable */
// @ts-nocheck
// @ts-ignore
var __STORY__ = "import { CryptoAddress } from '.';\n\nexport default {\n  component: CryptoAddress,\n  title: 'Utilities/CryptoAddress',\n};\n\nexport const Default = (args: any) => (\n  <CryptoAddress {...args}>\n    0xd8da6bf26964af9d7eed9e03e53415d37aa96045\n  </CryptoAddress>\n);\n\nexport const withRightHint = (args: any) => (\n  <CryptoAddress {...args}>\n    0xd8da6bf26964af9d7eed9e03e53415d37aa96045\n  </CryptoAddress>\n);\n\nDefault.args = {};\n\nwithRightHint.args = {\n  hintPosition: 'right',\n};\n"; // @ts-ignore

var __LOCATIONS_MAP__ = {
  "Default": {
    "startLoc": {
      "col": 23,
      "line": 8
    },
    "endLoc": {
      "col": 1,
      "line": 12
    },
    "startBody": {
      "col": 23,
      "line": 8
    },
    "endBody": {
      "col": 1,
      "line": 12
    }
  },
  "withRightHint": {
    "startLoc": {
      "col": 29,
      "line": 14
    },
    "endLoc": {
      "col": 1,
      "line": 18
    },
    "startBody": {
      "col": 29,
      "line": 14
    },
    "endBody": {
      "col": 1,
      "line": 18
    }
  }
};



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  component: ___WEBPACK_IMPORTED_MODULE_0__.CryptoAddress,
  title: 'Utilities/CryptoAddress'
});
const Default = args => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(ReactComment, {
    "data-anima": "{\"componentData\":{\"pkg\":\"src/components/CryptoAddress/CryptoAddress\",\"tagName\":\"CryptoAddress\"}}"
  }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(___WEBPACK_IMPORTED_MODULE_0__.CryptoAddress, { ...args,
    "is-anima": "true",
    children: "0xd8da6bf26964af9d7eed9e03e53415d37aa96045"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 17,
    columnNumber: 3
  }, undefined)]
}, void 0, true);
_c = Default;
;
const withRightHint = args => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(ReactComment, {
    "data-anima": "{\"componentData\":{\"pkg\":\"src/components/CryptoAddress/CryptoAddress\",\"tagName\":\"CryptoAddress\"}}"
  }, void 0, false, void 0, void 0), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(___WEBPACK_IMPORTED_MODULE_0__.CryptoAddress, { ...args,
    "is-anima": "true",
    children: "0xd8da6bf26964af9d7eed9e03e53415d37aa96045"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 23,
    columnNumber: 3
  }, undefined)]
}, void 0, true);
Default.args = {};
withRightHint.args = {
  hintPosition: 'right'
};
Default.parameters = {
  storySource: {
    source: "(args: any) => (\n  <CryptoAddress {...args}>\n    0xd8da6bf26964af9d7eed9e03e53415d37aa96045\n  </CryptoAddress>\n)"
  },
  ...Default.parameters
};
withRightHint.parameters = {
  storySource: {
    source: "(args: any) => (\n  <CryptoAddress {...args}>\n    0xd8da6bf26964af9d7eed9e03e53415d37aa96045\n  </CryptoAddress>\n)"
  },
  ...withRightHint.parameters
};

if (!window.ReactComment) {
  window.ReactComment = props => {
    try {
      const React = __webpack_require__(/*! react */ "./node_modules/react/index.js");

      const animaData = props['data-anima'];
      if (!animaData) return null;
      const ref = React.createRef();
      React.useLayoutEffect(() => {
        let el = null;
        let parent = null;
        let comm = null;

        if (ref.current) {
          el = ref.current;
          parent = el.parentNode;
          comm = window.document.createComment(animaData);

          try {
            if (parent && parent.contains(el)) {
              parent.replaceChild(comm, el);
            }
          } catch (err) {
            console.error(err);
          }
        }

        return () => {
          if (parent && el && comm) {
            parent.replaceChild(el, comm);
          }
        };
      }, []);
      return React.createElement('span', {
        ref,
        style: {
          display: 'none'
        }
      }, []);
    } catch (e) {
      return null;
    }
  };
}

window["__ANIMA__STORY__./src/components/CryptoAddress/CryptoAddress.stories.tsx"] = {
  "imports": {
    "src/components/CryptoAddress": [{
      "name": "CryptoAddress",
      "isDefault": false,
      "key": "src/components/CryptoAddress/CryptoAddress"
    }],
    "react/jsx-dev-runtime": [{
      "name": "_jsxDEV",
      "isDefault": false,
      "key": "react/jsx-dev-runtime/_jsxDEV"
    }]
  },
  "title": "Utilities/CryptoAddress",
  "component": "CryptoAddress"
};

var _c;

__webpack_require__.$Refresh$.register(_c, "Default");
const __namedExportsOrder = ["Default", "withRightHint"];

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}
try {
    // @ts-ignore
    Default.displayName = "Default";
    // @ts-ignore
    Default.__docgenInfo = { "description": "", "displayName": "Default", "props": {} };
    // @ts-ignore
    if (typeof STORYBOOK_REACT_CLASSES !== "undefined")
        // @ts-ignore
        STORYBOOK_REACT_CLASSES["src/components/CryptoAddress/CryptoAddress.stories.tsx#Default"] = { docgenInfo: Default.__docgenInfo, name: "Default", path: "src/components/CryptoAddress/CryptoAddress.stories.tsx#Default" };
}
catch (__react_docgen_typescript_loader_error) { }
try {
    // @ts-ignore
    withRightHint.displayName = "withRightHint";
    // @ts-ignore
    withRightHint.__docgenInfo = { "description": "", "displayName": "withRightHint", "props": {} };
    // @ts-ignore
    if (typeof STORYBOOK_REACT_CLASSES !== "undefined")
        // @ts-ignore
        STORYBOOK_REACT_CLASSES["src/components/CryptoAddress/CryptoAddress.stories.tsx#withRightHint"] = { docgenInfo: withRightHint.__docgenInfo, name: "withRightHint", path: "src/components/CryptoAddress/CryptoAddress.stories.tsx#withRightHint" };
}
catch (__react_docgen_typescript_loader_error) { }

/***/ })

});
//# sourceMappingURL=main.9d87988cd0ca8392809c.hot-update.js.map