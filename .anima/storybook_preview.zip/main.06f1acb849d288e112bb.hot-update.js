"use strict";
globalThis["webpackHotUpdate_map3xyz_components"]("main",{

/***/ "./src/components/Pill/Pill.tsx":
/*!**************************************!*\
  !*** ./src/components/Pill/Pill.tsx ***!
  \**************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/@storybook/builder-webpack5/node_modules/react/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/@storybook/builder-webpack5/node_modules/react/jsx-dev-runtime.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var _jsxFileName = "/Users/philiplondon/Projects/map3/components/src/components/Pill/Pill.tsx";



const Pill = props => {
  let text = '';
  let bg = '';
  let border = '';
  let dotBg = '';

  switch (props.color) {
    case 'green':
      text = 'text-green-500';
      border = 'border-green-800';
      dotBg = 'bg-green-500';
      bg = 'bg-green-900/50';
      break;

    case 'red':
      text = 'text-red-500';
      border = 'border-red-800';
      dotBg = 'bg-red-500';
      bg = 'bg-red-900/50';
      break;

    case 'yellow':
      text = 'text-yellow-500';
      border = 'border-yellow-800';
      dotBg = 'bg-yellow-500';
      bg = 'bg-yellow-900/50';
      break;

    case 'blue':
      text = 'text-blue-500';
      border = 'border-blue-800';
      dotBg = 'bg-blue-500';
      bg = 'bg-blue-900/50';
      break;

    default:
      text = 'text-gray-400';
      border = 'border-gray-600';
      dotBg = 'bg-gray-400';
      bg = 'bg-gray-600/50';
      break;
  }

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", { ...props,
    className: `flex items-center gap-1 rounded-full border py-1 px-2 text-xs font-semibold ${text} ${border} ${bg} ${props.className}`,
    children: [props.dot ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("span", {
      className: `h-2 w-2 rounded-full ${dotBg}`
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 47,
      columnNumber: 9
    }, undefined) : null, props.icon ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("span", {
      className: `${text} !bg-transparent`,
      children: props.icon
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 50,
      columnNumber: 9
    }, undefined) : null, props.children]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 42,
    columnNumber: 5
  }, undefined);
};

_c = Pill;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Pill);

if (!window.ReactComment) {
  window.ReactComment = props => {
    try {
      const React = __webpack_require__(/*! react */ "./node_modules/@storybook/builder-webpack5/node_modules/react/index.js");

      const animaData = props['data-anima'];
      if (!animaData) return null;
      const ref = React.createRef();
      React.useLayoutEffect(() => {
        let el = null;
        let parent = null;
        let comm = null;

        if (ref.current) {
          el = ref.current;
          parent = el.parentNode;
          comm = window.document.createComment(animaData);

          try {
            if (parent && parent.contains(el)) {
              parent.replaceChild(comm, el);
            }
          } catch (err) {
            console.error(err);
          }
        }

        return () => {
          if (parent && el && comm) {
            parent.replaceChild(el, comm);
          }
        };
      }, []);
      return React.createElement('span', {
        ref,
        style: {
          display: 'none'
        }
      }, []);
    } catch (e) {
      return null;
    }
  };
}

var _c;

__webpack_require__.$Refresh$.register(_c, "Pill");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}
try {
    // @ts-ignore
    Pill.displayName = "Pill";
    // @ts-ignore
    Pill.__docgenInfo = { "description": "", "displayName": "Pill", "props": { "className": { "defaultValue": null, "description": "", "name": "className", "required": false, "type": { "name": "string" } }, "color": { "defaultValue": null, "description": "", "name": "color", "required": true, "type": { "name": "enum", "value": [{ "value": "\"green\"" }, { "value": "\"gray\"" }, { "value": "\"red\"" }, { "value": "\"blue\"" }, { "value": "\"yellow\"" }] } }, "dot": { "defaultValue": null, "description": "", "name": "dot", "required": false, "type": { "name": "boolean" } }, "icon": { "defaultValue": null, "description": "", "name": "icon", "required": false, "type": { "name": "ReactElement<any, string | JSXElementConstructor<any>>" } } } };
    // @ts-ignore
    if (typeof STORYBOOK_REACT_CLASSES !== "undefined")
        // @ts-ignore
        STORYBOOK_REACT_CLASSES["src/components/Pill/Pill.tsx#Pill"] = { docgenInfo: Pill.__docgenInfo, name: "Pill", path: "src/components/Pill/Pill.tsx#Pill" };
}
catch (__react_docgen_typescript_loader_error) { }

/***/ })

});
//# sourceMappingURL=main.06f1acb849d288e112bb.hot-update.js.map